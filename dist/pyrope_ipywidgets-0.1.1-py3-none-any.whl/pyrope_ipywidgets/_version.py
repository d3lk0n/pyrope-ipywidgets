
version_info = (0, 1, 1)
__version__ = ".".join(map(str, version_info))
