"use strict";
(self["webpackChunkpyrope_ipywidgets"] = self["webpackChunkpyrope_ipywidgets"] || []).push([["lib_widgets_js"],{

/***/ "./lib/version.js":
/*!************************!*\
  !*** ./lib/version.js ***!
  \************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.MODULE_NAME = exports.MODULE_VERSION = void 0;
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
// eslint-disable-next-line @typescript-eslint/no-var-requires
const data = __webpack_require__(/*! ../package.json */ "./package.json");
/**
 * The _model_module_version/_view_module_version this package implements.
 *
 * The html widget manager assumes that this is the same as the npm package
 * version number.
 */
exports.MODULE_VERSION = data.version;
/*
 * The current package name.
 */
exports.MODULE_NAME = data.name;


/***/ }),

/***/ "./lib/widgets.js":
/*!************************!*\
  !*** ./lib/widgets.js ***!
  \************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TextAreaView = exports.TextAreaModel = exports.TextView = exports.TextModel = exports.SliderView = exports.SliderModel = exports.RadioButtonsView = exports.RadioButtonsModel = exports.DropdownView = exports.DropdownModel = exports.CheckboxView = exports.CheckboxModel = exports.InputWidgetView = exports.InputWidgetModel = exports.ExerciseView = exports.ExerciseModel = exports.PyRopeWidgetView = exports.PyRopeWidgetModel = void 0;
__webpack_require__(/*! bootstrap-icons/font/bootstrap-icons.css */ "./node_modules/bootstrap-icons/font/bootstrap-icons.css");
const base_1 = __webpack_require__(/*! @jupyter-widgets/base */ "webpack/sharing/consume/default/@jupyter-widgets/base?ea51");
const controls_1 = __webpack_require__(/*! @jupyter-widgets/controls */ "webpack/sharing/consume/default/@jupyter-widgets/controls/@jupyter-widgets/controls");
const output_1 = __webpack_require__(/*! @jupyter-widgets/output */ "webpack/sharing/consume/default/@jupyter-widgets/output/@jupyter-widgets/output");
const widgets_1 = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
__webpack_require__(/*! ../css/widgets.css */ "./css/widgets.css");
const version_1 = __webpack_require__(/*! ./version */ "./lib/version.js");
// Base model class for all PyRope widget models.
class PyRopeWidgetModel extends base_1.DOMWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { _model_module: PyRopeWidgetModel.model_module, _model_module_version: PyRopeWidgetModel.model_module_version, _model_name: PyRopeWidgetModel.model_name, _view_module: PyRopeWidgetModel.view_module, _view_module_version: PyRopeWidgetModel.view_module_version, _view_name: PyRopeWidgetModel.view_name });
    }
}
exports.PyRopeWidgetModel = PyRopeWidgetModel;
PyRopeWidgetModel.model_module = version_1.MODULE_NAME;
PyRopeWidgetModel.model_module_version = version_1.MODULE_VERSION;
PyRopeWidgetModel.model_name = 'PyRopeWidgetModel';
PyRopeWidgetModel.view_module = version_1.MODULE_NAME;
PyRopeWidgetModel.view_module_version = version_1.MODULE_VERSION;
PyRopeWidgetModel.view_name = 'PyRopeWidgetView';
// Base view class for all PyRope widget views.
class PyRopeWidgetView extends base_1.DOMWidgetView {
    constructor(...args) {
        super(...args);
        this.init_callbacks();
    }
    // Callbacks can be initialized in this method for readability purposes, so
    // that they do not have to be initialized in the render method.
    init_callbacks() { }
    // Render a mime model with the render mime registry inside a host element.
    // The host element needs to be attached to the DOM tree, otherwise the
    // model cannot be attached to the host.
    render_mime_model(model, host) {
        return __awaiter(this, void 0, void 0, function* () {
            const registry = PyRopeWidgetView.renderMimeRegistry;
            const mime_type = registry.preferredMimeType(model.data);
            if (mime_type !== undefined) {
                const renderer = registry.createRenderer(mime_type);
                yield renderer.renderModel(model);
                widgets_1.Widget.attach(renderer, host);
            }
        });
    }
    // Create and return a view for a given widget model.
    create_widget_view(model) {
        return __awaiter(this, void 0, void 0, function* () {
            const view = yield model.widget_manager.create_view(model);
            // The "displayed" event needs to be triggered manually to actually
            // render a widget.
            view.trigger('displayed');
            return view;
        });
    }
    // Render a widget model by creating its view and appending it to the
    // host element.
    render_widget_model(model, host) {
        return __awaiter(this, void 0, void 0, function* () {
            const view = yield this.create_widget_view(model);
            host.appendChild(view.el);
        });
    }
    // Render a map of mime or widget models with a given render function
    // inside a given domain.
    render_models(models, render, domain) {
        for (let [field_name, model] of models) {
            // A model which key is called field_name is rendered inside all
            // elements that have its field_name as value for the data
            // attribute "data-pyrope-field-name". Notice that models are only
            // rendered inside elements that are part of a given domain
            // element.
            const elements = domain.querySelectorAll(`[data-pyrope-field-name="${field_name}"]`);
            for (let i = 0; i < elements.length; i++) {
                render(model, elements[i]);
            }
        }
    }
    // Return a styled div element depending on the given type. Valid types
    // are info and warning. Raises an error for invalid types. The returned
    // container contains an icon which depends on the type and a span element
    // to show text.
    create_alert_box(type) {
        const container = document.createElement('div');
        container.classList.add('pyrope', 'alert');
        const icon = document.createElement('i');
        icon.classList.add('bi', 'pyrope');
        if (type === 'info') {
            container.classList.add('info');
            icon.classList.add('bi-info-circle');
        }
        else if (type === 'warning') {
            container.classList.add('warning');
            icon.classList.add('bi-exclamation-triangle');
        }
        else {
            throw new Error("Alert box type has to be either 'info' or 'warning'.");
        }
        const content = document.createElement('span');
        content.classList.add('pyrope', 'alert-content');
        container.append(icon, content);
        return container;
    }
    // Render an alert box with a specific text. The host to be a container
    // which is structured like containers returned by "create_alert_box"
    // method. Furthermore the host needs to have the "alert" css class.
    render_alert_box(host, text) {
        // The last child refers to the span element of an alert box.
        if (host.lastChild !== null) {
            host.lastChild.textContent = text;
        }
        // Hide the host container if the text string is empty and show it
        // otherwise.
        if (text === '') {
            host.classList.remove('show');
        }
        else {
            host.classList.add('show');
        }
    }
}
exports.PyRopeWidgetView = PyRopeWidgetView;
// Model class for PyRope's exercises.
class ExerciseModel extends PyRopeWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // List of markdown templates which are rendered as hints in the
            // _hints container.
            _displayed_hints: [], 
            // A markdown template which is rendered as feedback in the
            // _feedback container.
            _feedback: '', 
            // A dictionary where keys are output field names and values are
            // mime bundles. A mime bundle is a list of two dictionaries. One
            // dictionary contains representations of a Python object for
            // different mime types and the second one contains optional
            // metadata.
            _ofield_mime_bundles: {}, 
            // A markdown template which is rendered as the preamble in the
            // _preamble container.
            _preamble: '', 
            // A markdown template which is rendered as the exercise's problem
            // in the _problem container. This is the only template where one
            // can use placeholders to render widgets.
            _problem: '', 
            // A string which is rendered inside the _total_score_container
            // div element.
            _total_score: '', 
            // Ipywidgets button model which clears all debug messages.
            clear_debug_btn: controls_1.ButtonModel, 
            // Boolean flag indicating the debug mode of an exercise.
            debug: false, 
            // Ipywidgets output model for showing debug messages.
            debug_output: output_1.OutputModel, 
            // Ipywidgets button model which renders the next hint if there is
            // one.
            hint_btn: controls_1.ButtonModel, 
            // Ipywidgets button model for submitting an exercise.
            submit_btn: controls_1.ButtonModel, 
            // Ipywidgets output model for showing standard output and errors
            // of an exercise's template methods.
            user_output: output_1.OutputModel, 
            // A string which is rendered inside _warning container. If the
            // string is empty, _warning will not be displayed.
            warning: '', 
            // A dictionary where keys are widget ids and values are widget
            // models.
            widgets: {} });
    }
}
exports.ExerciseModel = ExerciseModel;
ExerciseModel.serializers = Object.assign(Object.assign({}, base_1.DOMWidgetModel.serializers), { clear_debug_btn: { deserialize: base_1.unpack_models }, debug_output: { deserialize: base_1.unpack_models }, hint_btn: { deserialize: base_1.unpack_models }, submit_btn: { deserialize: base_1.unpack_models }, user_output: { deserialize: base_1.unpack_models }, widgets: { deserialize: base_1.unpack_models } });
ExerciseModel.model_name = 'ExerciseModel';
ExerciseModel.view_name = 'ExerciseView';
// View class for PyRope's exercises.
class ExerciseView extends PyRopeWidgetView {
    init_callbacks() {
        this.model.on('change:_ofield_mime_bundles', this.create_ofield_models, this);
        this.model.on('change:_feedback', this.render_feedback, this);
        this.model.on('change:_displayed_hints', this.render_hints, this);
        this.model.on('change:_preamble', this.render_preamble, this);
        this.model.on('change:_problem', this.render_problem, this);
        this.model.on('change:_total_score', () => {
            this.render_alert_box(this._total_score_container, this.model.get('_total_score'));
        }, this);
        this.model.on('change:debug', this.change_debug, this);
        this.model.on('change:warning', () => {
            this.render_alert_box(this._warning, this.model.get('warning'));
        }, this);
    }
    // Since models can only be rendered if the host element is attached to
    // the DOM tree (see PyRopeWidgetView.render_mime_model), the _render
    // method is executed after the container element of an exercise (this.el)
    // was attached.
    render() {
        this.displayed.then(() => this._render());
    }
    _render() {
        return __awaiter(this, void 0, void 0, function* () {
            this._user_output_area = document.createElement('div');
            this._user_output_area.classList.add('pyrope', 'user-output');
            this._preamble = document.createElement('div');
            this._preamble.classList.add('pyrope', 'preamble');
            this._preamble_separator = this.new_separator();
            // Only show a separator after the preamble if there actually is a
            // preamble.
            this._preamble_separator.classList.add('hide');
            this._problem = document.createElement('div');
            this._problem.classList.add('pyrope', 'problem');
            this._button_area = document.createElement('div');
            this._button_area.classList.add('pyrope', 'button-area');
            this._warning = this.create_alert_box('warning');
            this._hints = document.createElement('div');
            this._hints.classList.add('pyrope', 'hints');
            this._feedback = document.createElement('div');
            this._feedback.classList.add('pyrope', 'feedback');
            this._feedback_separator = this.new_separator();
            // Only show a separator after the feedback if there actually is
            // feedback.
            this._feedback_separator.classList.add('hide');
            this._total_score_container = this.create_alert_box('info');
            this._debug_area = document.createElement('div');
            this._debug_area.classList.add('pyrope', 'debug');
            this._debug_area_separator = this.new_separator();
            // Only show a separator after the debug area if the debug mode is on.
            this._debug_area_separator.classList.add('hide');
            // Append all elements to the host element of this view.
            this.el.append(this._user_output_area, this.new_separator(), this._preamble, this._preamble_separator, this._problem, this._button_area, this._warning, this._hints, this.new_separator(), this._feedback, this._total_score_container, this._feedback_separator, this._debug_area, this._debug_area_separator);
            // Call the rendering methods.
            this.create_ofield_models();
            this.render_user_output_area();
            this.render_preamble();
            this.render_problem();
            this.populate_button_area();
            this.render_alert_box(this._warning, this.model.get('warning'));
            this.render_hints();
            this.render_feedback();
            this.render_alert_box(this._total_score_container, this.model.get('_total_score'));
            this.render_debug_area();
        });
    }
    // If the debug mode changes, the buttons, the debug and the user output
    // area need to be rerendered.
    change_debug() {
        this.render_user_output_area();
        this.populate_button_area();
        this.render_debug_area();
    }
    // Everytime the model's _ofield_mime_bundles attribute gets updated, this
    // method converts all mime bundles to mime models with the help of the
    // render mime registry.
    create_ofield_models() {
        this._ofield_models = new Map();
        let mime_types = this.model.get('_ofield_mime_bundles');
        for (let name in mime_types) {
            let format_dict = mime_types[name][0];
            let metadata = mime_types[name][1];
            let model = PyRopeWidgetView.renderMimeRegistry.createModel({ 'data': format_dict, 'metadata': metadata });
            this._ofield_models.set(name, model);
        }
    }
    // Return a styled hr element for separating specific sections of an
    // exercise.
    new_separator() {
        let separator = document.createElement('hr');
        separator.classList.add('pyrope');
        return separator;
    }
    // Render the user output area depending on the current debug mode.
    render_user_output_area() {
        return __awaiter(this, void 0, void 0, function* () {
            // Clear the user output area in case it was already rendered.
            this._user_output_area.replaceChildren();
            // Only show the user output area if the debug mode is enabled.
            if (this.model.get('debug')) {
                const user_output_view = yield this.create_widget_view(this.model.get('user_output'));
                this._user_output_area.append(user_output_view.el);
            }
        });
    }
    // Render the preamble and only show a separator after the preamble if
    // there actually is one.
    render_preamble() {
        const preamble_template = this.model.get('_preamble');
        this.render_ofields(preamble_template, this._preamble);
        if (preamble_template === '') {
            this._preamble_separator.classList.add('hide');
        }
        else {
            this._preamble_separator.classList.remove('hide');
        }
    }
    // Render the buttons of an exercise inside the button area. Which buttons
    // are shown, depends on the debug mode.
    populate_button_area() {
        return __awaiter(this, void 0, void 0, function* () {
            // Clear the button area in case it was already rendered.
            this._button_area.replaceChildren();
            // Create the submit and hint button and append them to the button
            // container. These buttons are always rendered.
            const submit_btn_view = yield this.create_widget_view(this.model.get('submit_btn'));
            const hint_btn_view = yield this.create_widget_view(this.model.get('hint_btn'));
            this._button_area.append(submit_btn_view.el, hint_btn_view.el);
            // The button for clearing the debug messages is only shown if the
            // debug mode is on.
            if (this.model.get('debug')) {
                const clear_debug_btn_view = yield this.create_widget_view(this.model.get('clear_debug_btn'));
                this._button_area.append(clear_debug_btn_view.el);
            }
        });
    }
    // Render the whole template with a Markdown renderer and then render all
    // output fields. Render the output fields first and then render the
    // template does not work for some reason.
    render_ofields(template, host) {
        return __awaiter(this, void 0, void 0, function* () {
            // Set the sanitized template so that all placeholder spans are
            // inserted into the DOM.
            template = PyRopeWidgetView.renderMimeRegistry.sanitizer.sanitize(template);
            host.innerHTML = template;
            if (template === '') {
                return;
            }
            // All placeholder spans inside of a LaTeX environment need to be
            // replaced with the plain representation of the corresponding output
            // field. Otherwise these output fields could not be considered by the
            // Markdown renderer.
            this.render_models(this._ofield_models, (model, model_host) => {
                model_host.classList.add('pyrope', 'field', 'ofield');
                const format_spec = model_host.getAttribute('data-pyrope-format-spec');
                if (format_spec === 'latex') {
                    model_host.replaceWith(String(model.data['text/plain']));
                }
            }, host);
            // Clear the host div and render the template with a markdown
            // renderer.
            const template_model = PyRopeWidgetView.renderMimeRegistry.createModel({ 'data': { 'text/markdown': host.innerHTML } });
            host.replaceChildren();
            yield this.render_mime_model(template_model, host);
            // Render all output fields outside of an LaTeX environment inside
            // their placeholder span.
            this.render_models(this._ofield_models, this.render_mime_model, host);
        });
    }
    // Render the problem.
    render_problem() {
        return __awaiter(this, void 0, void 0, function* () {
            // Get the problem template and render all output fields.
            const problem_template = this.model.get('_problem');
            yield this.render_ofields(problem_template, this._problem);
            // Create a widget map with widget ids as keys and widget models as
            // values.
            const widgets = this.model.get('widgets');
            let widgets_map = new Map();
            for (let widget_id in widgets) {
                widgets_map.set(widget_id, widgets[widget_id]);
            }
            // Render the widget models.
            this.render_models(widgets_map, (widget_model, widget_host) => __awaiter(this, void 0, void 0, function* () {
                widget_host.classList.add('pyrope', 'field', 'ifield');
                this.render_widget_model(widget_model, widget_host);
            }), this._problem);
        });
    }
    // Render all hints which are stored inside the attribute _displayed_hints.
    // Each hint is rendered inside an info alert box.
    render_hints() {
        const hints = this.model.get('_displayed_hints');
        this._hints.replaceChildren();
        for (let hint of hints) {
            const hint_container = this.create_alert_box('info');
            hint_container.classList.add('show');
            this._hints.append(hint_container);
            if (hint_container.lastChild !== null) {
                this.render_ofields(hint, hint_container.lastChild);
            }
        }
    }
    // Render feedback and only show a separator after the feedback section if
    // there actually is feedback.
    render_feedback() {
        const feedback_template = this.model.get('_feedback');
        this.render_ofields(feedback_template, this._feedback);
        if (feedback_template === '') {
            this._feedback_separator.classList.add('hide');
        }
        else {
            this._feedback_separator.classList.remove('hide');
        }
    }
    // Render the debug area depending on the current debug mode.
    render_debug_area() {
        return __awaiter(this, void 0, void 0, function* () {
            // Clear the debug area in case it was already rendered.
            this._debug_area.replaceChildren();
            // Render the debug output and show the separator if the debug mode is
            // on and hide the separator otherwise.
            if (this.model.get('debug')) {
                const debug_output_view = yield this.create_widget_view(this.model.get('debug_output'));
                const container = document.createElement('div');
                this._debug_area.appendChild(container);
                container.appendChild(debug_output_view.el);
                this._debug_area_separator.classList.remove('hide');
            }
            else {
                this._debug_area_separator.classList.add('hide');
            }
        });
    }
}
exports.ExerciseView = ExerciseView;
// Base model class for PyRope's input widgets.
class InputWidgetModel extends PyRopeWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // A string which is rendered inside the _score_span container.
            _score: '', 
            // A mime bundle which is a list of two dictionaries. One contains
            // representations of the solution Python object for different
            // mime types and the second one contains optional metadata.
            _solution_mime_bundle: [], 
            // A boolean flag indicating whether the widget's input is correct
            // or not.
            correct: null, 
            // A boolean flag indicating if the widgets is disabled or not.
            disabled: false, 
            // A string which is shown when hovering over the widget.
            title: '', 
            // A boolean flag indicating whether the widget's input is valid
            // or not.
            valid: null });
    }
}
exports.InputWidgetModel = InputWidgetModel;
InputWidgetModel.serializers = Object.assign({}, base_1.DOMWidgetModel.serializers);
InputWidgetModel.model_name = 'InputWidgetModel';
InputWidgetModel.view_name = 'InputWidgetView';
// Base view class for PyRope's input widgets. After every input widget a
// button for toggling a tooltip showing the score and the solution of a widget
// is rendered.
class InputWidgetView extends PyRopeWidgetView {
    // Since every widget has the following attributes their callbacks are
    // initialized in the parent class.
    init_callbacks() {
        this.model.on('change:_score', this.render_score, this);
        this.model.on('change:_solution_mime_bundle', this.render_solution, this);
        this.model.on('change:disabled', this.change_disabled, this);
        this.model.on('change:title', this.change_title, this);
        this.model.on('change:valid', this.change_valid, this);
        this.model.on('change:value', this.change_value, this);
    }
    // General render method for PyRope's input widgets. This method should be
    // invoked inside the render method of child classes so that every widget
    // has a button to show the solution and score. It should be called at the
    // end of the child class' render method so that the button will be
    // rendered behind an input widget.
    render() {
        // Take attribute's current values into account to render the view.
        // With that it is not necessary to call these methods in child
        // classes.
        this.change_disabled();
        this.change_title();
        this.change_valid();
        this.change_value();
        // Create a container which contains the result button.
        const tooltip_container = document.createElement('div');
        tooltip_container.classList.add('pyrope', 'tooltip');
        this.el.appendChild(tooltip_container);
        // Create a button for showing the results.
        this._result_btn = document.createElement('button');
        this._result_btn.classList.add('pyrope', 'ifield');
        this._result_btn.onclick = this.toggle_tooltip.bind(this);
        // Create a question mark icon.
        const question_icon = document.createElement('i');
        question_icon.classList.add('bi', 'bi-question-circle', 'pyrope');
        // Create _tooltip, _score_span, _result_separator and _solution_span
        // and append them to the tooltip container.
        this._tooltip = document.createElement('span');
        this._tooltip.classList.add('pyrope');
        this._score_span = document.createElement('span');
        this._result_separator = document.createElement('hr');
        this._result_separator.classList.add('pyrope', 'tooltip', 'hide');
        this._solution_span = document.createElement('span');
        this._tooltip.append(this._solution_span, this._result_separator, this._score_span);
        this._result_btn.append(question_icon, this._tooltip);
        tooltip_container.appendChild(this._result_btn);
        // Render the current score and solution inside the tooltip. The
        // rendering methods need to be called after this.el is displayed and
        // therefore part of the DOM tree because otherwise mime models cannot
        // be rendered. This is specifically needed to render solutions.
        this.displayed.then(() => {
            this.render_score();
            this.render_solution();
        });
    }
    // Abstract callback methods if an attribute gets updated. These methods
    // should be implemented in child classes.
    change_disabled() { }
    change_title() { }
    change_valid() { }
    change_value() { }
    // Render the score inside _score_span.
    render_score() {
        const score = this.model.get('_score');
        // If there is no score and no solution to show, the result button
        // is disabled.
        if (score === '' &&
            this.model.get('_solution_mime_bundle').length === 0) {
            this._result_btn.disabled = true;
        }
        else {
            this._result_btn.disabled = false;
        }
        // If there is a score and a solution to show, score and solution are
        // separated by a horizonzal line. Otherwise the separator is hidden.
        if (score !== '' &&
            this.model.get('_solution_mime_bundle').length !== 0) {
            this._result_separator.classList.remove('hide');
        }
        else {
            this._result_separator.classList.add('hide');
        }
        // Set the score string.
        this._score_span.textContent = score;
    }
    // Render the solution inside _solution_span.
    render_solution() {
        // Clear the solution span in case a solution was already rendered.
        this._solution_span.replaceChildren();
        const solution = this.model.get('_solution_mime_bundle');
        // If there is no score and no solution to show, the result button
        // is disabled.
        if (solution.length === 0 && this.model.get('_score') === '') {
            this._result_btn.disabled = true;
        }
        else {
            this._result_btn.disabled = false;
        }
        // If there is a score and a solution to show, score and solution are
        // separated by a horizonzal line. Otherwise the separator is hidden.
        if (solution.length !== 0 && this.model.get('_score') !== '') {
            this._result_separator.classList.remove('hide');
        }
        else {
            this._result_separator.classList.add('hide');
        }
        // Return if there is no mime bundle to render.
        if (solution.length === 0) {
            return;
        }
        // Create and render the solution mime model.
        const model = PyRopeWidgetView.renderMimeRegistry.createModel({ 'data': solution[0], 'metadata': solution[1] });
        this.render_mime_model(model, this._solution_span);
    }
    // Show or hide the tooltip.
    toggle_tooltip() {
        this._tooltip.classList.toggle('show');
    }
    // Return a valid css widget class name depending on a boolean value.
    get_class_name(value) {
        let class_name = 'pyrope';
        if (value === true) {
            class_name = 'pyrope valid';
        }
        else if (value === false) {
            class_name = 'pyrope invalid';
        }
        return class_name;
    }
    // Change the css class name of any DOM element. The class name is
    // determined by the model's attributes "disabled", "correct" and
    // "valid".
    change_class_name(element) {
        // Disable or enable the given element. This is important because the
        // style of an element can change based on if it is enabled or
        // disabled.
        const disabled = this.model.get('disabled');
        element.disabled = disabled;
        // If an input widget is disabled, it changes its style depending
        // on if the input is correct or not. If it is enabled, the style
        // changes based on if the input is valid or not.
        if (disabled === true) {
            element.className = this.get_class_name(this.model.get('correct'));
        }
        else {
            element.className = this.get_class_name(this.model.get('valid'));
        }
    }
}
exports.InputWidgetView = InputWidgetView;
class CheckboxModel extends InputWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // Checkboxes can only have true or false as a value. Defaults to
            // false which means that the Checkbox is unchecked.
            value: false });
    }
}
exports.CheckboxModel = CheckboxModel;
CheckboxModel.model_name = 'CheckboxModel';
CheckboxModel.view_name = 'CheckboxView';
class CheckboxView extends InputWidgetView {
    render() {
        // Create the checkbox element and bind a callback which is triggered
        // when the checkbox is clicked.
        this._checkbox = document.createElement('input');
        this._checkbox.type = 'checkbox';
        this._checkbox.onclick = this.change_on_click.bind(this);
        // Render the checkbox.
        this.el.append(this._checkbox);
        super.render();
    }
    change_disabled() {
        this.change_class_name(this._checkbox);
    }
    // Update the model when the state of the checkbox changes. This method is
    // bound to the click event of a checkbox.
    change_on_click() {
        this.model.set('value', this._checkbox.checked);
        this.model.save_changes();
    }
    change_title() {
        this._checkbox.title = this.model.get('title');
    }
    change_valid() {
        this.change_class_name(this._checkbox);
    }
    change_value() {
        this._checkbox.checked = this.model.get('value');
    }
}
exports.CheckboxView = CheckboxView;
class DropdownModel extends InputWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // The index of the currently selected option.
            _index: null, 
            // A list of strings which are rendered to represent the options.
            labels: [] });
    }
}
exports.DropdownModel = DropdownModel;
DropdownModel.model_name = 'DropdownModel';
DropdownModel.view_name = 'DropdownView';
class DropdownView extends InputWidgetView {
    init_callbacks() {
        super.init_callbacks();
        this.model.on('change:_index', this.change_index, this);
        this.model.on('change:labels', this.change_labels, this);
    }
    render() {
        // Create the dropdown and and bind a callback which is triggered when
        // the selected label changes.
        this._select = document.createElement('select');
        this._select.onchange = this.change_on_change.bind(this);
        // Render the labels and select the label which is currently selected
        // according to the model.
        this.change_labels();
        this.change_index();
        // Render the dropdown.
        this.el.append(this._select);
        super.render();
    }
    change_disabled() {
        this.change_class_name(this._select);
    }
    // If the model's _index gets updated, a new label needs to be selected.
    // Notice that the (i + 1)th label is selected because of the additional
    // default option.
    change_index() {
        const i = this.model.get('_index');
        if (i !== null) {
            this._select.options[i + 1].selected = true;
        }
    }
    // Render the labels inside the select element.
    change_labels() {
        // Clear the select element in case that labels were already rendered.
        this._select.replaceChildren();
        // Create a hidden and empty default option which is selected by
        // default. Otherwise the first label would be selected by default.
        // Notice that this default option has to be considered when using
        // the selectedIndex attribute of the select element.
        const default_option = document.createElement('option');
        default_option.disabled = true;
        default_option.hidden = true;
        default_option.selected = true;
        this._select.append(default_option);
        // Create an option element for every label and append it to the
        // select element.
        const labels = this.model.get('labels');
        labels.forEach((element) => {
            const option = document.createElement('option');
            option.textContent = element;
            this._select.append(option);
        });
    }
    // Update the model when the selected label changes. _index has to be
    // updated to selectedIndex - 1 because of the additional default option.
    change_on_change() {
        this.model.set('_index', this._select.selectedIndex - 1);
        this.model.save_changes();
    }
    change_title() {
        this._select.title = this.model.get('title');
    }
    change_valid() {
        this.change_class_name(this._select);
    }
}
exports.DropdownView = DropdownView;
class RadioButtonsModel extends InputWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // The index of the currently selected option.
            _index: null, 
            // A list of markdown templates which are rendered to represent the
            // options.
            labels: [], 
            // Whether to render the radio buttons vertically or not.
            vertical: true });
    }
}
exports.RadioButtonsModel = RadioButtonsModel;
RadioButtonsModel.model_name = 'RadioButtonsModel';
RadioButtonsModel.view_name = 'RadioButtonsView';
class RadioButtonsView extends InputWidgetView {
    init_callbacks() {
        super.init_callbacks();
        this.model.on('change:_index', this.change_index, this);
        this.model.on('change:labels', this.change_labels, this);
        this.model.on('change:vertical', this.change_labels, this);
    }
    // Since labels can be markdown templates they have to be rendered with the
    // help of the render mime registry. This only works after the view is
    // displayed which means that this.el is part of the DOM tree.
    render() {
        this.displayed.then(() => this._render());
    }
    _render() {
        // Create the container.
        this._container = document.createElement('div');
        this._container.classList.add('pyrope');
        // Render the radio buttons and select the radio button which is
        // currently selected according to the model.
        this.change_labels();
        this.change_index();
        // Render the container.
        this.el.append(this._container);
        super.render();
    }
    change_disabled() {
        this._radio_buttons.forEach((btn) => {
            this.change_class_name(btn);
        });
    }
    change_index() {
        const i = this.model.get('_index');
        if (i !== null) {
            this._radio_buttons[i].checked = true;
        }
    }
    // Render the radio buttons with the corresponding labels.
    change_labels() {
        // Clear the array and container in case that radio buttons were
        // already rendered.
        this._radio_buttons = new Array();
        this._container.replaceChildren();
        // Add a css class to the base container to render radio buttons
        // vertically.
        const vertical = this.model.get('vertical');
        if (vertical) {
            this.el.classList.add('pyrope-vertical-radio-buttons');
        }
        else {
            this.el.classList.remove('pyrope-vertical-radio-buttons');
        }
        const labels = this.model.get('labels');
        labels.forEach((element) => __awaiter(this, void 0, void 0, function* () {
            // Create a radio button for every label. Use the view id (cid)
            // to connect multiple radio buttons to one radio button group.
            // Every view has a different cid therefore only radio buttons
            // of one specific view are considered as one group. Furthermore
            // add a callback to every radio button which gets triggered every
            // time the selected radio button changes.
            const radio_button = document.createElement('input');
            radio_button.type = 'radio';
            radio_button.classList.add('pyrope');
            radio_button.name = this.cid;
            radio_button.addEventListener('change', () => {
                this.change_on_change(this, radio_button);
            });
            this._radio_buttons.push(radio_button);
            // Create a label element and append it right behind the
            // corresponding radio button inside the DOM tree. Since labels
            // are markdown templates they have to be rendered via the render
            // mime registry.
            const label = document.createElement('label');
            label.classList.add('pyrope');
            this._container.append(radio_button, label);
            if (vertical) {
                this._container.append(document.createElement('br'));
            }
            const label_model = PyRopeWidgetView.renderMimeRegistry
                .createModel({ 'data': { 'text/markdown': element } });
            yield this.render_mime_model(label_model, label);
        }));
    }
    // Update the model when the selected radio button changes.
    change_on_change(view, radio_button) {
        view.model.set('_index', this._radio_buttons.indexOf(radio_button));
        view.model.save_changes();
    }
    change_title() {
        this._container.title = this.model.get('title');
    }
    change_valid() {
        this._radio_buttons.forEach((btn) => {
            this.change_class_name(btn);
        });
    }
}
exports.RadioButtonsView = RadioButtonsView;
class SliderModel extends InputWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // The slider's maximal value.
            maximum: 100.0, 
            // The slider's minimal value.
            minimum: 0.0, 
            // The step size while sliding.
            step: 1.0, 
            // The slider's current value.
            value: 0.0, 
            // The slider's width in percent. The percentage refers to the
            // width of the container the slider is contained by.
            width: 25 });
    }
}
exports.SliderModel = SliderModel;
SliderModel.model_name = 'SliderModel';
SliderModel.view_name = 'SliderView';
class SliderView extends InputWidgetView {
    init_callbacks() {
        super.init_callbacks();
        this.model.on('change:maximum', this.change_maximum, this);
        this.model.on('change:minimum', this.change_minimum, this);
        this.model.on('change:step', this.change_step, this);
        this.model.on('change:width', this.change_width, this);
    }
    render() {
        // Create the slider element.
        this._slider = document.createElement('input');
        this._slider.type = 'range';
        // Show and update the slider info container when an interaction
        // begins. Notice that mouse and touch events have to treated
        // separatly.
        this._slider.addEventListener('mousedown', () => {
            this.update_slider_info();
            this._slider_info.classList.toggle('show');
        });
        this._slider.addEventListener('touchstart', () => {
            this.update_slider_info();
            this._slider_info.classList.toggle('show');
        });
        // Update the slider info container when the slider's value changes.
        this._slider.addEventListener('input', () => {
            this.update_slider_info();
        });
        // Update the model and hide the info container when an interaction
        // ends.
        this._slider.addEventListener('mouseup', () => {
            this.change_on_interaction_end();
            this._slider_info.classList.toggle('show');
        });
        this._slider.addEventListener('touchend', () => {
            this.change_on_interaction_end();
            this._slider_info.classList.toggle('show');
        });
        // Consider the current values of the model's attributes to build the
        // view.
        this.change_maximum();
        this.change_minimum();
        this.change_step();
        this.change_width();
        // Create the slider info container and a div element which contains
        // the slider element and the info container.
        const container = document.createElement('div');
        container.classList.add('pyrope', 'slider-container');
        this._slider_info = document.createElement('div');
        this._slider_info.classList.add('pyrope', 'slider-info');
        // Render the slider.
        container.append(this._slider, this._slider_info);
        this.el.append(container);
        super.render();
    }
    change_disabled() {
        this.change_class_name(this._slider);
    }
    change_maximum() {
        this._slider.max = this.model.get('maximum');
    }
    change_minimum() {
        this._slider.min = this.model.get('minimum');
    }
    // Update the model when the slider's value changes.
    change_on_interaction_end() {
        this.model.set('value', parseFloat(this._slider.value));
        this.model.save_changes();
    }
    change_step() {
        this._slider.step = this.model.get('step');
    }
    change_title() {
        this._slider.title = this.model.get('title');
    }
    change_valid() {
        this.change_class_name(this._slider);
    }
    change_value() {
        this._slider.value = this.model.get('value');
        this.update_slider_info();
    }
    change_width() {
        this._slider.style.width = `${this.model.get('width')}%`;
    }
    // Set the content of _slider_info to the current value and calculate the
    // position of the info container so that it is always shown right above
    // the slider thumb.
    update_slider_info() {
        const thumb_width = parseInt(getComputedStyle(document.documentElement)
            .getPropertyValue('--slider-thumb-size'));
        const max = parseFloat(this._slider.max);
        const min = parseFloat(this._slider.min);
        const value = parseFloat(this._slider.value);
        this._slider_info.textContent = this._slider.value;
        const slider_width = this._slider.getBoundingClientRect().width;
        const info_width = this._slider_info.getBoundingClientRect().width;
        const ratio = (value - min) / (max - min);
        const offset = (ratio * (slider_width - thumb_width)) +
            (thumb_width / 2) - (info_width / 2);
        this._slider_info.style.left = `${offset}px`;
    }
}
exports.SliderView = SliderView;
class TextModel extends InputWidgetModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // A string which is shown inside the text input when the input is
            // empty.
            placeholder: '', 
            // The current value of the text input.
            value: '', 
            // The width of the text input. The value refers to the amount of
            // characters that fit into the text input.
            width: 20 });
    }
}
exports.TextModel = TextModel;
TextModel.model_name = 'TextModel';
TextModel.view_name = 'TextView';
class TextView extends InputWidgetView {
    init_callbacks() {
        super.init_callbacks();
        this.model.on('change:placeholder', this.change_placeholder, this);
        this.model.on('change:width', this.change_width, this);
    }
    // Create the text input element.
    create_input_element() {
        this._text = document.createElement('input');
        this._text.type = 'text';
    }
    render() {
        // Create the text input element and bind a callback which is triggered
        // when the input value changes.
        this.create_input_element();
        this._text.oninput = this.change_on_input.bind(this);
        // Consider the current values of the model's attributes to build the
        // view.
        this.change_placeholder();
        this.change_width();
        // Render the text input.
        this.el.append(this._text);
        super.render();
    }
    change_disabled() {
        this.change_class_name(this._text);
    }
    // Update the model when the value of the text input element changes.
    change_on_input() {
        this.model.set('value', this._text.value);
        this.model.save_changes();
    }
    change_placeholder() {
        this._text.placeholder = this.model.get('placeholder');
    }
    change_title() {
        this._text.title = this.model.get('title');
    }
    change_valid() {
        this.change_class_name(this._text);
    }
    change_value() {
        this._text.value = this.model.get('value');
    }
    change_width() {
        this._text.style.width = `${this.model.get('width')}ch`;
    }
}
exports.TextView = TextView;
class TextAreaModel extends TextModel {
    defaults() {
        return Object.assign(Object.assign({}, super.defaults()), { 
            // The height of the text area. The value refers to the amount of
            // rows that fit into the text area element.
            height: 4, 
            // The width of the text area. The value refers to the amount of
            // characters that fit into the text area element.
            width: 50 });
    }
}
exports.TextAreaModel = TextAreaModel;
TextAreaModel.model_name = 'TextAreaModel';
TextAreaModel.view_name = 'TextAreaView';
class TextAreaView extends TextView {
    init_callbacks() {
        super.init_callbacks();
        this.model.on('change:height', this.change_height, this);
    }
    render() {
        super.render();
        this.change_height();
    }
    create_input_element() {
        this._text = document.createElement('textarea');
    }
    change_height() {
        this._text.rows = this.model.get('height');
    }
}
exports.TextAreaView = TextAreaView;


/***/ }),

/***/ "./node_modules/css-loader/dist/cjs.js!./css/widgets.css":
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./css/widgets.css ***!
  \***************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `
/* Global variables */
:root {
    --blue: #1476fb;
    --light-blue: #b8e2f4;
    --red: #ff0000;
    --light-red: #ffcccb;
    --grey: #8b8b8b;
    --light-grey: #efefef;
    --yellow: #f8b35e;
    --light-yellow: #fcdfb7;
    --black: #000000;
    --slider-thumb-size: 14px;
}

.pyrope {
    margin-top: 3px;
    margin-bottom: 3px;
    font-size: 14px;
    line-height: 1;
    font-family: var(--jp-ui-font-family);
}

hr.pyrope {
    border: 1px solid #cccccc;
    border-radius: 3px;
}
hr.pyrope.hide {
    display: none;
}
hr.pyrope.tooltip {
    margin: 3px 0px;
    border-top: 1px solid var(--grey);
}

div.pyrope {
    padding: 1ch 2ch;
}
div.pyrope:empty {
    display: none;
}
div.pyrope.problem div.lm-Widget[data-mime-type="text/markdown"] {
    overflow: visible;
}
div.pyrope.user-output {
    padding: 0px;
}

div.lm-Widget:has(div.pyrope) {
    overflow: visible;
}

div.pyrope.alert {
    margin: 1ch 2ch;
    padding: 0.5ch 2ch;
    display: none;
    width: fit-content;
    border-width: 1px;
    border-style: solid;
    border-radius: 2px;
}
div.pyrope.alert.show {
    display: flex;
    align-items: center;
}
div.pyrope.alert span.pyrope.alert-content {
    padding-left: 1.5ch;
}
div.pyrope.alert.warning {
    border-color: var(--yellow);
    background-color: var(--light-yellow);
}
div.pyrope.alert.info {
    border-color: var(--blue);
    background-color: var(--light-blue);
}
div.pyrope.alert i.bi.pyrope {
    font-size: 20px;
}

div.pyrope.hints {
    padding-top: 1ch;
    padding-bottom: 0ch;
    padding-left: 0ch;
    padding-right: 0ch;
}
div.pyrope.hints div.pyrope.info .jp-RenderedHTMLCommon code {
    background-color: inherit;
}

div.pyrope.tooltip {
    display: inline-block;
    position: relative;
}
button.pyrope.ifield {
    cursor: pointer;
    border: 1px solid var(--grey);
    margin-left: 3px;
    padding-bottom: 3px;
}
button.pyrope.ifield:disabled {
    cursor: not-allowed;
}
button.pyrope.ifield i.bi.pyrope {
    font-size: 12px;
}
button.pyrope.ifield span.pyrope {
    visibility: collapse;
    transition: opacity 0.3s;
    position: absolute;
    z-index: 1;
    opacity: 0;
}
button.pyrope.ifield span.show {
    display: block;
    visibility: visible;
    top: 105%;
    left: 30%;
    background-color: var(--light-grey);
    height: fit-content;
    border: 1px solid var(--grey);
    border-radius: 0px 5px 5px 5px;
    opacity: 1;
    padding: 3px 3px;
    width: max-content;
}
button.pyrope.ifield span.show span {
    display: block;
    padding: 0px 10px;
}

/* Last paragraph does not need margin so that the preamble is vertically
centered between its separators. */
div.pyrope div[data-mime-type="text/markdown"] p:last-of-type {
    margin: 0px;
}

span.pyrope.field div, pre {
    display: inline;
    padding: 0px !important;
    background-color: inherit !important;
    font-family: var(--jp-ui-font-family) !important;
}

div.pyrope.debug > div:first-child {
    border: 1px solid var(--grey);
    border-radius: 5px;
}
div.pyrope.debug > div:first-child > div.lm-Widget.widget-output {
    min-height: 100px;
    max-height: 300px;
    overflow-y: auto;
}

/* Checkbox widget. */
input[type="checkbox"].pyrope {
	-webkit-appearance: none;
    border: 1px solid var(--grey);
    width: 13px;
    height: 13px;
    border-radius: 2px;
    vertical-align: middle;
}
input[type="checkbox"].pyrope:focus {
    outline: none;
}
input[type="checkbox"].pyrope:hover:enabled {
	box-shadow: 0px 0px 1px var(--black);
}
input[type="checkbox"].pyrope:checked::before {
	content: "";
    display: block;
    width: 2px;
    height: 4px;
    background-color: var(--black);
    transform: translateX(2px) translateY(6px) rotate(-50deg);
}
input[type="checkbox"].pyrope:checked::after {
	content: "";
    display: block;
    width: 2px;
    height: 8px;
    background-color: var(--black);
    transform: translateX(6px) translateY(-3px) rotate(38deg);
}
input[type="checkbox"].pyrope.invalid:checked::before {
	background-color: var(--red);
}
input[type="checkbox"].pyrope.invalid:checked::after {
	background-color: var(--red);
}
input[type="checkbox"].pyrope.invalid {
	border-color: var(--red);
    background-color: var(--light-red);
}
input[type="checkbox"].pyrope.valid:disabled {
	border-color: var(--blue);
    background-color: var(--light-blue);
}
input[type="checkbox"].pyrope.valid:disabled::before {
	background-color: var(--blue);
}
input[type="checkbox"].pyrope.valid:disabled::after {
	background-color: var(--blue);
}

/* Dropdown widget. */
select.pyrope {
	border: 1px solid var(--grey);
    border-radius: 2px;
}
select.pyrope.invalid {
	color: var(--red);
    border-color: var(--red);
    background-color: var(--light-red);
}
select.pyrope.invalid option {
	color: black;
}
select.pyrope.invalid:focus {
    outline-color: var(--red);
}
select.pyrope.valid:disabled {
	color: var(--blue);
    border-color: var(--blue);
    background-color: var(--light-blue);
}

/* RadioButtons widget. */
input[type="radio"].pyrope {
	-webkit-appearance: none;
    width: 1em;
    height: 1em;
    border: 1px solid var(--grey);
    border-radius: 50%;
    vertical-align: text-bottom;
}
input[type="radio"].pyrope:focus {
    outline: none;
}
input[type="radio"].pyrope:checked {
	background-image: radial-gradient(
    	circle,
        var(--black) 0%,
        var(--black) 40%,
        transparent 50%,
        transparent 100%
	);
}
input[type="radio"].pyrope:hover:enabled {
	box-shadow: 0px 0px 1px var(--black);
}
input[type="radio"].pyrope.invalid {
	border-color: var(--red);
    background-color: var(--light-red);
}
input[type="radio"].pyrope.invalid:checked {
	background-image: radial-gradient(
    	circle,
        var(--red) 0%,
        var(--red) 40%,
        transparent 50%,
        transparent 100%
	);
}
input[type="radio"].pyrope.valid:disabled {
	border-color: var(--blue);
    background-color: var(--light-blue);
}
input[type="radio"].pyrope.valid:disabled:checked {
	background-image: radial-gradient(
    	circle,
        var(--blue) 0%,
        var(--blue) 40%,
        transparent 50%,
        transparent 100%
	);
}
input[type="radio"].pyrope + label.pyrope {
    display: inline-block;
    padding-right: 5px;
}
div.lm-Widget.pyrope-vertical-radio-buttons {
    display: inline-flex !important;
    align-items: center;
}

/* Slider widget. */
input[type="range"].pyrope {
    -webkit-appearance: none;
    background-color: var(--light-grey);
    height: 5px;
    border-radius: 10px;
    border: 1px solid var(--grey);
    width: 25%;
    vertical-align: middle;
    display: inline;
}
input[type="range"].pyrope::-webkit-slider-thumb {
    -webkit-appearance: none;
    background: var(--black);
    border-radius: 50%;
    cursor: pointer;
    height: var(--slider-thumb-size);
    width: var(--slider-thumb-size);
}
input[type="range"].pyrope.invalid {
	border-color: var(--red);
    background-color: var(--light-red);
}
input[type="range"].pyrope.invalid::-webkit-slider-thumb {
	background: var(--red);
}
input[type="range"].pyrope.valid:disabled {
	border-color: var(--blue);
    background-color: var(--light-blue);
}
input[type="range"].pyrope.valid:disabled::-webkit-slider-thumb {
	background: var(--blue);
}
input[type="range"].pyrope::-moz-range-thumb {
    -webkit-appearance: none;
    background: var(--black);
    border-width: 0px;
    border-radius: 50%;
    cursor: pointer;
    height: var(--slider-thumb-size);
    width: var(--slider-thumb-size);
}
input[type="range"].pyrope.valid:disabled::-moz-range-thumb {
	background: var(--blue);
}
input[type="range"].pyrope.invalid::-moz-range-thumb {
	background: var(--red);
}
div.pyrope.slider-container {
    position: relative;
}
span.pyrope.field div.pyrope.slider-info {
    visibility: collapse;
    position: absolute;
    bottom: 14px;
    border: 1px solid var(--grey);
    border-radius: 2px;
    background-color: var(--light-grey) !important;
    min-width: 25px;
    text-align: center;
    z-index: 2;
    padding: 1px 3px !important;
}
span.pyrope.field div.pyrope.slider-info.show {
    visibility: visible;
}

/* Text widget. */
input[type="text"].pyrope {
	border: 1px solid var(--grey);
    border-radius: 2px;
    padding: 2px;
    vertical-align: middle;
}
input[type="text"].pyrope:focus {
	border-color: var(--black);
	outline-color: var(--black);
	outline-style: solid;
}
input[type="text"].pyrope.invalid {
    border-color: var(--red);
    color: var(--red);
}
input[type="text"].pyrope.invalid:focus {
    outline-color: var(--red);
}
input[type="text"].pyrope.invalid:disabled {
	background-color: var(--light-red);
}
input[type="text"].pyrope.valid {
    border-color: var(--blue);
}
input[type="text"].pyrope.valid:focus {
    outline-color: var(--blue);
}
input[type="text"].pyrope.valid:disabled {
	color: var(--blue);
    background-color: var(--light-blue);
}

/* TextArea widget. */
textarea.pyrope {
	border: 1px solid var(--grey);
    border-radius: 2px;
    padding: 2px;
    vertical-align: middle;
}
textarea.pyrope:focus {
	outline-style: solid;
    outline-color: var(--black);
    border-color: var(--black);
}
textarea.pyrope.invalid {
    border-color: var(--red);
    color: var(--red);
}
textarea.pyrope.invalid:focus {
    outline-color: var(--red);
}
textarea.pyrope.invalid:disabled {
	background-color: var(--light-red);
}
textarea.pyrope.valid {
    border-color: var(--blue);
}
textarea.pyrope.valid:focus {
    outline-color: var(--blue);
}
textarea.pyrope.valid:disabled {
	color: var(--blue);
    background-color: var(--light-blue);
}
`, "",{"version":3,"sources":["webpack://./css/widgets.css"],"names":[],"mappings":";AACA,qBAAqB;AACrB;IACI,eAAe;IACf,qBAAqB;IACrB,cAAc;IACd,oBAAoB;IACpB,eAAe;IACf,qBAAqB;IACrB,iBAAiB;IACjB,uBAAuB;IACvB,gBAAgB;IAChB,yBAAyB;AAC7B;;AAEA;IACI,eAAe;IACf,kBAAkB;IAClB,eAAe;IACf,cAAc;IACd,qCAAqC;AACzC;;AAEA;IACI,yBAAyB;IACzB,kBAAkB;AACtB;AACA;IACI,aAAa;AACjB;AACA;IACI,eAAe;IACf,iCAAiC;AACrC;;AAEA;IACI,gBAAgB;AACpB;AACA;IACI,aAAa;AACjB;AACA;IACI,iBAAiB;AACrB;AACA;IACI,YAAY;AAChB;;AAEA;IACI,iBAAiB;AACrB;;AAEA;IACI,eAAe;IACf,kBAAkB;IAClB,aAAa;IACb,kBAAkB;IAClB,iBAAiB;IACjB,mBAAmB;IACnB,kBAAkB;AACtB;AACA;IACI,aAAa;IACb,mBAAmB;AACvB;AACA;IACI,mBAAmB;AACvB;AACA;IACI,2BAA2B;IAC3B,qCAAqC;AACzC;AACA;IACI,yBAAyB;IACzB,mCAAmC;AACvC;AACA;IACI,eAAe;AACnB;;AAEA;IACI,gBAAgB;IAChB,mBAAmB;IACnB,iBAAiB;IACjB,kBAAkB;AACtB;AACA;IACI,yBAAyB;AAC7B;;AAEA;IACI,qBAAqB;IACrB,kBAAkB;AACtB;AACA;IACI,eAAe;IACf,6BAA6B;IAC7B,gBAAgB;IAChB,mBAAmB;AACvB;AACA;IACI,mBAAmB;AACvB;AACA;IACI,eAAe;AACnB;AACA;IACI,oBAAoB;IACpB,wBAAwB;IACxB,kBAAkB;IAClB,UAAU;IACV,UAAU;AACd;AACA;IACI,cAAc;IACd,mBAAmB;IACnB,SAAS;IACT,SAAS;IACT,mCAAmC;IACnC,mBAAmB;IACnB,6BAA6B;IAC7B,8BAA8B;IAC9B,UAAU;IACV,gBAAgB;IAChB,kBAAkB;AACtB;AACA;IACI,cAAc;IACd,iBAAiB;AACrB;;AAEA;kCACkC;AAClC;IACI,WAAW;AACf;;AAEA;IACI,eAAe;IACf,uBAAuB;IACvB,oCAAoC;IACpC,gDAAgD;AACpD;;AAEA;IACI,6BAA6B;IAC7B,kBAAkB;AACtB;AACA;IACI,iBAAiB;IACjB,iBAAiB;IACjB,gBAAgB;AACpB;;AAEA,qBAAqB;AACrB;CACC,wBAAwB;IACrB,6BAA6B;IAC7B,WAAW;IACX,YAAY;IACZ,kBAAkB;IAClB,sBAAsB;AAC1B;AACA;IACI,aAAa;AACjB;AACA;CACC,oCAAoC;AACrC;AACA;CACC,WAAW;IACR,cAAc;IACd,UAAU;IACV,WAAW;IACX,8BAA8B;IAC9B,yDAAyD;AAC7D;AACA;CACC,WAAW;IACR,cAAc;IACd,UAAU;IACV,WAAW;IACX,8BAA8B;IAC9B,yDAAyD;AAC7D;AACA;CACC,4BAA4B;AAC7B;AACA;CACC,4BAA4B;AAC7B;AACA;CACC,wBAAwB;IACrB,kCAAkC;AACtC;AACA;CACC,yBAAyB;IACtB,mCAAmC;AACvC;AACA;CACC,6BAA6B;AAC9B;AACA;CACC,6BAA6B;AAC9B;;AAEA,qBAAqB;AACrB;CACC,6BAA6B;IAC1B,kBAAkB;AACtB;AACA;CACC,iBAAiB;IACd,wBAAwB;IACxB,kCAAkC;AACtC;AACA;CACC,YAAY;AACb;AACA;IACI,yBAAyB;AAC7B;AACA;CACC,kBAAkB;IACf,yBAAyB;IACzB,mCAAmC;AACvC;;AAEA,yBAAyB;AACzB;CACC,wBAAwB;IACrB,UAAU;IACV,WAAW;IACX,6BAA6B;IAC7B,kBAAkB;IAClB,2BAA2B;AAC/B;AACA;IACI,aAAa;AACjB;AACA;CACC;;;;;;EAMC;AACF;AACA;CACC,oCAAoC;AACrC;AACA;CACC,wBAAwB;IACrB,kCAAkC;AACtC;AACA;CACC;;;;;;EAMC;AACF;AACA;CACC,yBAAyB;IACtB,mCAAmC;AACvC;AACA;CACC;;;;;;EAMC;AACF;AACA;IACI,qBAAqB;IACrB,kBAAkB;AACtB;AACA;IACI,+BAA+B;IAC/B,mBAAmB;AACvB;;AAEA,mBAAmB;AACnB;IACI,wBAAwB;IACxB,mCAAmC;IACnC,WAAW;IACX,mBAAmB;IACnB,6BAA6B;IAC7B,UAAU;IACV,sBAAsB;IACtB,eAAe;AACnB;AACA;IACI,wBAAwB;IACxB,wBAAwB;IACxB,kBAAkB;IAClB,eAAe;IACf,gCAAgC;IAChC,+BAA+B;AACnC;AACA;CACC,wBAAwB;IACrB,kCAAkC;AACtC;AACA;CACC,sBAAsB;AACvB;AACA;CACC,yBAAyB;IACtB,mCAAmC;AACvC;AACA;CACC,uBAAuB;AACxB;AACA;IACI,wBAAwB;IACxB,wBAAwB;IACxB,iBAAiB;IACjB,kBAAkB;IAClB,eAAe;IACf,gCAAgC;IAChC,+BAA+B;AACnC;AACA;CACC,uBAAuB;AACxB;AACA;CACC,sBAAsB;AACvB;AACA;IACI,kBAAkB;AACtB;AACA;IACI,oBAAoB;IACpB,kBAAkB;IAClB,YAAY;IACZ,6BAA6B;IAC7B,kBAAkB;IAClB,8CAA8C;IAC9C,eAAe;IACf,kBAAkB;IAClB,UAAU;IACV,2BAA2B;AAC/B;AACA;IACI,mBAAmB;AACvB;;AAEA,iBAAiB;AACjB;CACC,6BAA6B;IAC1B,kBAAkB;IAClB,YAAY;IACZ,sBAAsB;AAC1B;AACA;CACC,0BAA0B;CAC1B,2BAA2B;CAC3B,oBAAoB;AACrB;AACA;IACI,wBAAwB;IACxB,iBAAiB;AACrB;AACA;IACI,yBAAyB;AAC7B;AACA;CACC,kCAAkC;AACnC;AACA;IACI,yBAAyB;AAC7B;AACA;IACI,0BAA0B;AAC9B;AACA;CACC,kBAAkB;IACf,mCAAmC;AACvC;;AAEA,qBAAqB;AACrB;CACC,6BAA6B;IAC1B,kBAAkB;IAClB,YAAY;IACZ,sBAAsB;AAC1B;AACA;CACC,oBAAoB;IACjB,2BAA2B;IAC3B,0BAA0B;AAC9B;AACA;IACI,wBAAwB;IACxB,iBAAiB;AACrB;AACA;IACI,yBAAyB;AAC7B;AACA;CACC,kCAAkC;AACnC;AACA;IACI,yBAAyB;AAC7B;AACA;IACI,0BAA0B;AAC9B;AACA;CACC,kBAAkB;IACf,mCAAmC;AACvC","sourcesContent":["\r\n/* Global variables */\r\n:root {\r\n    --blue: #1476fb;\r\n    --light-blue: #b8e2f4;\r\n    --red: #ff0000;\r\n    --light-red: #ffcccb;\r\n    --grey: #8b8b8b;\r\n    --light-grey: #efefef;\r\n    --yellow: #f8b35e;\r\n    --light-yellow: #fcdfb7;\r\n    --black: #000000;\r\n    --slider-thumb-size: 14px;\r\n}\r\n\r\n.pyrope {\r\n    margin-top: 3px;\r\n    margin-bottom: 3px;\r\n    font-size: 14px;\r\n    line-height: 1;\r\n    font-family: var(--jp-ui-font-family);\r\n}\r\n\r\nhr.pyrope {\r\n    border: 1px solid #cccccc;\r\n    border-radius: 3px;\r\n}\r\nhr.pyrope.hide {\r\n    display: none;\r\n}\r\nhr.pyrope.tooltip {\r\n    margin: 3px 0px;\r\n    border-top: 1px solid var(--grey);\r\n}\r\n\r\ndiv.pyrope {\r\n    padding: 1ch 2ch;\r\n}\r\ndiv.pyrope:empty {\r\n    display: none;\r\n}\r\ndiv.pyrope.problem div.lm-Widget[data-mime-type=\"text/markdown\"] {\r\n    overflow: visible;\r\n}\r\ndiv.pyrope.user-output {\r\n    padding: 0px;\r\n}\r\n\r\ndiv.lm-Widget:has(div.pyrope) {\r\n    overflow: visible;\r\n}\r\n\r\ndiv.pyrope.alert {\r\n    margin: 1ch 2ch;\r\n    padding: 0.5ch 2ch;\r\n    display: none;\r\n    width: fit-content;\r\n    border-width: 1px;\r\n    border-style: solid;\r\n    border-radius: 2px;\r\n}\r\ndiv.pyrope.alert.show {\r\n    display: flex;\r\n    align-items: center;\r\n}\r\ndiv.pyrope.alert span.pyrope.alert-content {\r\n    padding-left: 1.5ch;\r\n}\r\ndiv.pyrope.alert.warning {\r\n    border-color: var(--yellow);\r\n    background-color: var(--light-yellow);\r\n}\r\ndiv.pyrope.alert.info {\r\n    border-color: var(--blue);\r\n    background-color: var(--light-blue);\r\n}\r\ndiv.pyrope.alert i.bi.pyrope {\r\n    font-size: 20px;\r\n}\r\n\r\ndiv.pyrope.hints {\r\n    padding-top: 1ch;\r\n    padding-bottom: 0ch;\r\n    padding-left: 0ch;\r\n    padding-right: 0ch;\r\n}\r\ndiv.pyrope.hints div.pyrope.info .jp-RenderedHTMLCommon code {\r\n    background-color: inherit;\r\n}\r\n\r\ndiv.pyrope.tooltip {\r\n    display: inline-block;\r\n    position: relative;\r\n}\r\nbutton.pyrope.ifield {\r\n    cursor: pointer;\r\n    border: 1px solid var(--grey);\r\n    margin-left: 3px;\r\n    padding-bottom: 3px;\r\n}\r\nbutton.pyrope.ifield:disabled {\r\n    cursor: not-allowed;\r\n}\r\nbutton.pyrope.ifield i.bi.pyrope {\r\n    font-size: 12px;\r\n}\r\nbutton.pyrope.ifield span.pyrope {\r\n    visibility: collapse;\r\n    transition: opacity 0.3s;\r\n    position: absolute;\r\n    z-index: 1;\r\n    opacity: 0;\r\n}\r\nbutton.pyrope.ifield span.show {\r\n    display: block;\r\n    visibility: visible;\r\n    top: 105%;\r\n    left: 30%;\r\n    background-color: var(--light-grey);\r\n    height: fit-content;\r\n    border: 1px solid var(--grey);\r\n    border-radius: 0px 5px 5px 5px;\r\n    opacity: 1;\r\n    padding: 3px 3px;\r\n    width: max-content;\r\n}\r\nbutton.pyrope.ifield span.show span {\r\n    display: block;\r\n    padding: 0px 10px;\r\n}\r\n\r\n/* Last paragraph does not need margin so that the preamble is vertically\r\ncentered between its separators. */\r\ndiv.pyrope div[data-mime-type=\"text/markdown\"] p:last-of-type {\r\n    margin: 0px;\r\n}\r\n\r\nspan.pyrope.field div, pre {\r\n    display: inline;\r\n    padding: 0px !important;\r\n    background-color: inherit !important;\r\n    font-family: var(--jp-ui-font-family) !important;\r\n}\r\n\r\ndiv.pyrope.debug > div:first-child {\r\n    border: 1px solid var(--grey);\r\n    border-radius: 5px;\r\n}\r\ndiv.pyrope.debug > div:first-child > div.lm-Widget.widget-output {\r\n    min-height: 100px;\r\n    max-height: 300px;\r\n    overflow-y: auto;\r\n}\r\n\r\n/* Checkbox widget. */\r\ninput[type=\"checkbox\"].pyrope {\r\n\t-webkit-appearance: none;\r\n    border: 1px solid var(--grey);\r\n    width: 13px;\r\n    height: 13px;\r\n    border-radius: 2px;\r\n    vertical-align: middle;\r\n}\r\ninput[type=\"checkbox\"].pyrope:focus {\r\n    outline: none;\r\n}\r\ninput[type=\"checkbox\"].pyrope:hover:enabled {\r\n\tbox-shadow: 0px 0px 1px var(--black);\r\n}\r\ninput[type=\"checkbox\"].pyrope:checked::before {\r\n\tcontent: \"\";\r\n    display: block;\r\n    width: 2px;\r\n    height: 4px;\r\n    background-color: var(--black);\r\n    transform: translateX(2px) translateY(6px) rotate(-50deg);\r\n}\r\ninput[type=\"checkbox\"].pyrope:checked::after {\r\n\tcontent: \"\";\r\n    display: block;\r\n    width: 2px;\r\n    height: 8px;\r\n    background-color: var(--black);\r\n    transform: translateX(6px) translateY(-3px) rotate(38deg);\r\n}\r\ninput[type=\"checkbox\"].pyrope.invalid:checked::before {\r\n\tbackground-color: var(--red);\r\n}\r\ninput[type=\"checkbox\"].pyrope.invalid:checked::after {\r\n\tbackground-color: var(--red);\r\n}\r\ninput[type=\"checkbox\"].pyrope.invalid {\r\n\tborder-color: var(--red);\r\n    background-color: var(--light-red);\r\n}\r\ninput[type=\"checkbox\"].pyrope.valid:disabled {\r\n\tborder-color: var(--blue);\r\n    background-color: var(--light-blue);\r\n}\r\ninput[type=\"checkbox\"].pyrope.valid:disabled::before {\r\n\tbackground-color: var(--blue);\r\n}\r\ninput[type=\"checkbox\"].pyrope.valid:disabled::after {\r\n\tbackground-color: var(--blue);\r\n}\r\n\r\n/* Dropdown widget. */\r\nselect.pyrope {\r\n\tborder: 1px solid var(--grey);\r\n    border-radius: 2px;\r\n}\r\nselect.pyrope.invalid {\r\n\tcolor: var(--red);\r\n    border-color: var(--red);\r\n    background-color: var(--light-red);\r\n}\r\nselect.pyrope.invalid option {\r\n\tcolor: black;\r\n}\r\nselect.pyrope.invalid:focus {\r\n    outline-color: var(--red);\r\n}\r\nselect.pyrope.valid:disabled {\r\n\tcolor: var(--blue);\r\n    border-color: var(--blue);\r\n    background-color: var(--light-blue);\r\n}\r\n\r\n/* RadioButtons widget. */\r\ninput[type=\"radio\"].pyrope {\r\n\t-webkit-appearance: none;\r\n    width: 1em;\r\n    height: 1em;\r\n    border: 1px solid var(--grey);\r\n    border-radius: 50%;\r\n    vertical-align: text-bottom;\r\n}\r\ninput[type=\"radio\"].pyrope:focus {\r\n    outline: none;\r\n}\r\ninput[type=\"radio\"].pyrope:checked {\r\n\tbackground-image: radial-gradient(\r\n    \tcircle,\r\n        var(--black) 0%,\r\n        var(--black) 40%,\r\n        transparent 50%,\r\n        transparent 100%\r\n\t);\r\n}\r\ninput[type=\"radio\"].pyrope:hover:enabled {\r\n\tbox-shadow: 0px 0px 1px var(--black);\r\n}\r\ninput[type=\"radio\"].pyrope.invalid {\r\n\tborder-color: var(--red);\r\n    background-color: var(--light-red);\r\n}\r\ninput[type=\"radio\"].pyrope.invalid:checked {\r\n\tbackground-image: radial-gradient(\r\n    \tcircle,\r\n        var(--red) 0%,\r\n        var(--red) 40%,\r\n        transparent 50%,\r\n        transparent 100%\r\n\t);\r\n}\r\ninput[type=\"radio\"].pyrope.valid:disabled {\r\n\tborder-color: var(--blue);\r\n    background-color: var(--light-blue);\r\n}\r\ninput[type=\"radio\"].pyrope.valid:disabled:checked {\r\n\tbackground-image: radial-gradient(\r\n    \tcircle,\r\n        var(--blue) 0%,\r\n        var(--blue) 40%,\r\n        transparent 50%,\r\n        transparent 100%\r\n\t);\r\n}\r\ninput[type=\"radio\"].pyrope + label.pyrope {\r\n    display: inline-block;\r\n    padding-right: 5px;\r\n}\r\ndiv.lm-Widget.pyrope-vertical-radio-buttons {\r\n    display: inline-flex !important;\r\n    align-items: center;\r\n}\r\n\r\n/* Slider widget. */\r\ninput[type=\"range\"].pyrope {\r\n    -webkit-appearance: none;\r\n    background-color: var(--light-grey);\r\n    height: 5px;\r\n    border-radius: 10px;\r\n    border: 1px solid var(--grey);\r\n    width: 25%;\r\n    vertical-align: middle;\r\n    display: inline;\r\n}\r\ninput[type=\"range\"].pyrope::-webkit-slider-thumb {\r\n    -webkit-appearance: none;\r\n    background: var(--black);\r\n    border-radius: 50%;\r\n    cursor: pointer;\r\n    height: var(--slider-thumb-size);\r\n    width: var(--slider-thumb-size);\r\n}\r\ninput[type=\"range\"].pyrope.invalid {\r\n\tborder-color: var(--red);\r\n    background-color: var(--light-red);\r\n}\r\ninput[type=\"range\"].pyrope.invalid::-webkit-slider-thumb {\r\n\tbackground: var(--red);\r\n}\r\ninput[type=\"range\"].pyrope.valid:disabled {\r\n\tborder-color: var(--blue);\r\n    background-color: var(--light-blue);\r\n}\r\ninput[type=\"range\"].pyrope.valid:disabled::-webkit-slider-thumb {\r\n\tbackground: var(--blue);\r\n}\r\ninput[type=\"range\"].pyrope::-moz-range-thumb {\r\n    -webkit-appearance: none;\r\n    background: var(--black);\r\n    border-width: 0px;\r\n    border-radius: 50%;\r\n    cursor: pointer;\r\n    height: var(--slider-thumb-size);\r\n    width: var(--slider-thumb-size);\r\n}\r\ninput[type=\"range\"].pyrope.valid:disabled::-moz-range-thumb {\r\n\tbackground: var(--blue);\r\n}\r\ninput[type=\"range\"].pyrope.invalid::-moz-range-thumb {\r\n\tbackground: var(--red);\r\n}\r\ndiv.pyrope.slider-container {\r\n    position: relative;\r\n}\r\nspan.pyrope.field div.pyrope.slider-info {\r\n    visibility: collapse;\r\n    position: absolute;\r\n    bottom: 14px;\r\n    border: 1px solid var(--grey);\r\n    border-radius: 2px;\r\n    background-color: var(--light-grey) !important;\r\n    min-width: 25px;\r\n    text-align: center;\r\n    z-index: 2;\r\n    padding: 1px 3px !important;\r\n}\r\nspan.pyrope.field div.pyrope.slider-info.show {\r\n    visibility: visible;\r\n}\r\n\r\n/* Text widget. */\r\ninput[type=\"text\"].pyrope {\r\n\tborder: 1px solid var(--grey);\r\n    border-radius: 2px;\r\n    padding: 2px;\r\n    vertical-align: middle;\r\n}\r\ninput[type=\"text\"].pyrope:focus {\r\n\tborder-color: var(--black);\r\n\toutline-color: var(--black);\r\n\toutline-style: solid;\r\n}\r\ninput[type=\"text\"].pyrope.invalid {\r\n    border-color: var(--red);\r\n    color: var(--red);\r\n}\r\ninput[type=\"text\"].pyrope.invalid:focus {\r\n    outline-color: var(--red);\r\n}\r\ninput[type=\"text\"].pyrope.invalid:disabled {\r\n\tbackground-color: var(--light-red);\r\n}\r\ninput[type=\"text\"].pyrope.valid {\r\n    border-color: var(--blue);\r\n}\r\ninput[type=\"text\"].pyrope.valid:focus {\r\n    outline-color: var(--blue);\r\n}\r\ninput[type=\"text\"].pyrope.valid:disabled {\r\n\tcolor: var(--blue);\r\n    background-color: var(--light-blue);\r\n}\r\n\r\n/* TextArea widget. */\r\ntextarea.pyrope {\r\n\tborder: 1px solid var(--grey);\r\n    border-radius: 2px;\r\n    padding: 2px;\r\n    vertical-align: middle;\r\n}\r\ntextarea.pyrope:focus {\r\n\toutline-style: solid;\r\n    outline-color: var(--black);\r\n    border-color: var(--black);\r\n}\r\ntextarea.pyrope.invalid {\r\n    border-color: var(--red);\r\n    color: var(--red);\r\n}\r\ntextarea.pyrope.invalid:focus {\r\n    outline-color: var(--red);\r\n}\r\ntextarea.pyrope.invalid:disabled {\r\n\tbackground-color: var(--light-red);\r\n}\r\ntextarea.pyrope.valid {\r\n    border-color: var(--blue);\r\n}\r\ntextarea.pyrope.valid:focus {\r\n    outline-color: var(--blue);\r\n}\r\ntextarea.pyrope.valid:disabled {\r\n\tcolor: var(--blue);\r\n    background-color: var(--light-blue);\r\n}\r\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./css/widgets.css":
/*!*************************!*\
  !*** ./css/widgets.css ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_widgets_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./widgets.css */ "./node_modules/css-loader/dist/cjs.js!./css/widgets.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_widgets_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_widgets_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_widgets_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_widgets_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }),

/***/ "./package.json":
/*!**********************!*\
  !*** ./package.json ***!
  \**********************/
/***/ ((module) => {

module.exports = /*#__PURE__*/JSON.parse('{"name":"pyrope-ipywidgets","version":"0.1.0","description":"The JupyterLab extension providing Jupyter widgets for the e-assessment system PyRope.","keywords":["jupyter","jupyterlab","jupyterlab notebook","jupyterlab-extension","widgets","pyrope"],"files":["lib/**/*.js","dist/*.js","css/*.css"],"homepage":"https://github.com/PyRope-E-Assessment/pyrope-ipywidgets","bugs":{"url":"https://github.com/PyRope-E-Assessment/pyrope-ipywidgets/issues"},"repository":{"type":"git","url":"git+https://github.com/PyRope-E-Assessment/pyrope-ipywidgets.git"},"license":"AGPL-3.0-or-later","author":{"name":"Paul Brassel","email":"paul.brassel@htwk-leipzig.de"},"main":"lib/index.js","types":"./lib/index.d.ts","scripts":{"build":"jlpm run build:lib && jlpm run build:nbextension && jlpm run build:labextension:dev","build:prod":"jlpm run build:lib && jlpm run build:nbextension && jlpm run build:labextension","build:labextension":"jupyter labextension build .","build:labextension:dev":"jupyter labextension build --development True .","build:lib":"tsc","build:nbextension":"webpack","clean":"jlpm run clean:lib && jlpm run clean:nbextension && jlpm run clean:labextension","clean:lib":"rimraf lib","clean:labextension":"rimraf pyrope_ipywidgets/labextension","clean:nbextension":"rimraf pyrope_ipywidgets/nbextension/static/index.js","lint":"eslint . --ext .ts,.tsx --fix","lint:check":"eslint . --ext .ts,.tsx","prepack":"jlpm run build:lib","test":"jest","watch":"npm-run-all -p watch:*","watch:lib":"tsc -w","watch:nbextension":"webpack --watch --mode=development","watch:labextension":"jupyter labextension watch ."},"dependencies":{"@jupyter-widgets/base":"^1.1.10 || ^2 || ^3 || ^4 || ^5 || ^6","@jupyter-widgets/controls":"^5.0.11","@jupyter-widgets/output":"^6.0.10","@jupyterlab/rendermime":"^4.2.4","bootstrap-icons":"^1.11.3","svg-inline-loader":"^0.8.2"},"devDependencies":{"@babel/core":"^7.23.7","@babel/preset-env":"^7.23.8","@jupyter-widgets/base-manager":"^1.0.7","@jupyterlab/builder":"^4.0.11","@lumino/application":"^2.3.0","@lumino/widgets":"^2.3.1","@types/jest":"^29.5.11","@types/webpack-env":"^1.18.4","@typescript-eslint/eslint-plugin":"^6.19.1","@typescript-eslint/parser":"^6.19.1","acorn":"^8.11.3","css-loader":"^6.9.1","eslint":"^8.56.0","eslint-config-prettier":"^9.1.0","eslint-plugin-prettier":"^5.1.3","fs-extra":"^11.2.0","identity-obj-proxy":"^3.0.0","jest":"^29.7.0","mkdirp":"^3.0.1","npm-run-all":"^4.1.5","prettier":"^3.2.4","rimraf":"^5.0.5","source-map-loader":"^5.0.0","style-loader":"^3.3.4","ts-jest":"^29.1.2","ts-loader":"^9.5.1","typescript":"~5.3.3","webpack":"^5.90.0","webpack-cli":"^5.1.4"},"devDependenciesComments":{"@jupyterlab/builder":"pinned to the latest JupyterLab 3.x release","@lumino/application":"pinned to the latest Lumino 1.x release","@lumino/widgets":"pinned to the latest Lumino 1.x release"},"jupyterlab":{"extension":"lib/plugin","outputDir":"pyrope_ipywidgets/labextension/","sharedPackages":{"@jupyter-widgets/base":{"bundled":false,"singleton":true}}}}');

/***/ })

}]);
//# sourceMappingURL=lib_widgets_js.0e51ef58ddf0706dd843.js.map